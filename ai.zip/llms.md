# fhir.education.kursig#0.1.0: Samira utbildning

## Pages

* [Hem](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [Education Patient](StructureDefinition-EducationPatient.md)

### ImplementationGuides

* [Samira utbildning](index.md)

### Examples

* [patient-tolvan (Patient)](Patient-patient-tolvan.md)
