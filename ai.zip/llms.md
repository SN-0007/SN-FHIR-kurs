# fhir.education.kursig#0.1.0: Samira utbildning

## Pages

* [Hem](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [Education Encounter](StructureDefinition-EducationEncounter.md)
* [Education Patient](StructureDefinition-EducationPatient.md)

### ImplementationGuides

* [Samira utbildning](index.md)

### Examples

* [encounter-tolvan-1 (Encounter)](Encounter-encounter-tolvan-1.md)
* [patient-tolvan (Patient)](Patient-patient-tolvan.md)
